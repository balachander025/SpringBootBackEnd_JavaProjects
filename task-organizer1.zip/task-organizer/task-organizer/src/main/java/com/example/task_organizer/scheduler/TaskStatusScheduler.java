package com.example.task_organizer.scheduler;

import com.example.task_organizer.service.TaskService;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class TaskStatusScheduler {

    private final TaskService taskService;

    public TaskStatusScheduler(TaskService taskService) {
        this.taskService = taskService;
    }

    // DEMO: runs every X seconds from properties
    @Scheduled(fixedRateString = "${task.schedule.rate}")
    public void runTaskStatusUpdate() {

        System.out.println("\n==============================");
        System.out.println("⏰ Scheduler Started...");
        System.out.println("==============================");

        taskService.updateTaskStatus();   // update pending/overdue
        taskService.printDailySummary();  // print summary
    }


    // REAL INDUSTRY DAILY SCHEDULER (uncomment later)
    // Runs every day at 12 AM
    /*
    @Scheduled(cron = "${task.schedule.cron}")
    public void runDailyMidnightUpdate() {
        System.out.println("\n🌙 Midnight Scheduler Running...");
        taskService.updateTaskStatus();
        taskService.printDailySummary();
    }
    */
}
