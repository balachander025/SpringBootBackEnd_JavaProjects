package com.example.task_organizer.service;

import com.example.task_organizer.model.Task;
import com.example.task_organizer.model.User;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Map;

@Service
public class TaskService {

    private final UserService userService;

    public TaskService(UserService userService) {
        this.userService = userService;
    }

    // Add task to user
    public void addTask(String username, String title, LocalDate dueDate, String status) {

        User user = userService.getUser(username);

        if (user == null) {
            System.out.println("❌ User not found!");
            return;
        }

        Task task = new Task(title, dueDate);
        user.addTask(task);

        System.out.println("✅ Task added to " + username);
    }

    // Mark task completed
    public void completeTask(String username, String title) {
        User user = userService.getUser(username);

        if (user == null) return;

        for (Task t : user.getTasks()) {
            if (t.getTitle().equalsIgnoreCase(title)) {
                t.setStatus("Completed");
                System.out.println("✅ Task marked completed");
                return;
            }
        }

        System.out.println("Task not found");
    }

    // Update overdue tasks
    public void updateTaskStatus() {

        LocalDate today = LocalDate.now();

        for (Map.Entry<String, User> entry : userService.getAllUsers().entrySet()) {

            User user = entry.getValue();

            for (Task task : user.getTasks()) {

                if (!task.getStatus().equals("Completed")) {

                    if (today.isAfter(task.getDueDate())) {
                        task.setStatus("Overdue");
                    } else {
                        task.setStatus("Pending");
                    }
                }
            }
        }
    }

    // Daily summary
    public void printDailySummary() {

        System.out.println("\n📊 DAILY TASK SUMMARY");

        for (User user : userService.getAllUsers().values()) {

            int pending = 0;
            int completed = 0;
            int overdue = 0;

            for (Task task : user.getTasks()) {

                switch (task.getStatus()) {
                    case "Pending":
                        pending++;
                        break;
                    case "Completed":
                        completed++;
                        break;
                    case "Overdue":
                        overdue++;
                        break;
                }
            }

            System.out.println("\n👤 User: " + user.getUsername());
            System.out.println("Pending: " + pending);
            System.out.println("Completed: " + completed);
            System.out.println("Overdue: " + overdue);
        }
    }
}
