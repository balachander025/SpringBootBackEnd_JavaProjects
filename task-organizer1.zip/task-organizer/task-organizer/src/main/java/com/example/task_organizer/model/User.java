package com.example.task_organizer.model;

import java.util.ArrayList;
import java.util.List;

public class User {

    private String username;
    private List<Task> tasks = new ArrayList<>();

    public User(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    public List<Task> getTasks() {
        return tasks;
    }

    public void addTask(Task task) {
        tasks.add(task);
    }
}

