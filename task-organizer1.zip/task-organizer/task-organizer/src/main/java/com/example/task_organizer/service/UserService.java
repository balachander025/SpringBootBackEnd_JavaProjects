package com.example.task_organizer.service;

import com.example.task_organizer.model.User;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class UserService {

    private Map<String, User> userMap = new HashMap<>();

    public boolean addUser(String username) {
        if (userMap.containsKey(username)) {
            System.out.println("❌ Username already exists. Try another name.");
            return false;
        }

        userMap.put(username, new User(username));
        System.out.println("✅ User added: " + username);
        return true;
    }

    public User getUser(String username) {
        return userMap.get(username);
    }

    public Map<String, User> getAllUsers() {
        return userMap;
    }
}
