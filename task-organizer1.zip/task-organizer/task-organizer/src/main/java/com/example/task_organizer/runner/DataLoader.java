package com.example.task_organizer.runner;

import com.example.task_organizer.service.TaskService;
import com.example.task_organizer.service.UserService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import java.time.LocalDate;
import java.util.Scanner;

@Component
public class DataLoader implements CommandLineRunner {

    private final UserService userService;
    private final TaskService taskService;

    public DataLoader(UserService userService, TaskService taskService) {
        this.userService = userService;
        this.taskService = taskService;
    }

    @Override
    public void run(String... args) {

        Scanner sc = new Scanner(System.in);

        while (true) {

            System.out.println("\n===== TASK MENU =====");
            System.out.println("1. Add User");
            System.out.println("2. Add Task");
            System.out.println("3. Exit");

            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {

                // 🟢 ADD USER
                case 1:
                    String username;

                    while (true) {
                        System.out.print("Enter username (max 30 chars): ");
                        username = sc.nextLine().trim();

                        if (username.isEmpty()) {
                            System.out.println("❌ Username cannot be empty");
                            continue;
                        }

                        if (username.length() > 30) {
                            System.out.println("❌ Username must be within 30 characters");
                            continue;
                        }

                        break;
                    }

                    userService.addUser(username);
                    break;


                // 🟢 ADD TASK
                case 2:

                    System.out.print("Enter username: ");
                    String user = sc.nextLine().trim();

                    if (user.isEmpty()) {
                        System.out.println("❌ Username required");
                        break;
                    }

                    String title;

                    while (true) {
                        System.out.print("Enter task title (max 20 chars): ");
                        title = sc.nextLine().trim();

                        if (title.isEmpty()) {
                            System.out.println("❌ Task title cannot be empty");
                            continue;
                        }

                        if (title.length() > 20) {
                            System.out.println("❌ Task must be within 20 characters");
                            continue;
                        }

                        break;
                    }

                    String status;

                    while (true) {
                        System.out.print("Enter task status (Pending/Completed): ");
                        status = sc.nextLine().trim();

                        if (!(status.equalsIgnoreCase("Pending") ||
                                status.equalsIgnoreCase("Completed"))) {

                            System.out.println("❌ Enter only Pending or Completed");
                            continue;
                        }
                        break;
                    }

                    LocalDate dueDate = LocalDate.of(2026, 2, 13);

                    taskService.addTask(user, title, dueDate, status);
                    break;


                case 3:
                    System.exit(0);
            }
        }
    }
}
