package com.example.task_organizer.model;

import java.time.LocalDate;

public class Task {

    private String title;
    private LocalDate dueDate;
    private String status; // Pending, Completed, Overdue

    public Task(String title, LocalDate dueDate) {
        this.title = title;
        this.dueDate = dueDate;
        this.status = "Pending";
    }

    public String getTitle() {
        return title;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
