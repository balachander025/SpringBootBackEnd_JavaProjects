package com.example.task_organizer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskOrganizerApplicationTests {

	@Test
	void contextLoads() {
	}

}
