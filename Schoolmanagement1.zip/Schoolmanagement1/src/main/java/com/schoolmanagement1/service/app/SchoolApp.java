package com.schoolmanagement1.app;

import com.schoolmanagement1.service.School;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class SchoolApp {

    public static void main(String[] args) {

        School school = new School();

        // try-with-resources
        try (BufferedReader br =
                     new BufferedReader(new InputStreamReader(System.in))) {

            while (true) {
                System.out.println("\n1. Register Student");
                System.out.println("2. Register Teacher");
                System.out.println("3. Search by Name");
                System.out.println("4. Display All");
                System.out.println("5. Exit");
                System.out.print("Enter choice: ");

                int choice = Integer.parseInt(br.readLine());

                switch (choice) {
                    case 1:
                        System.out.print("Student Name: ");
                        String sName = br.readLine();

                        while (sName.trim().isEmpty()) {
                            System.out.print("Name cannot be empty. Enter again: ");
                            sName = br.readLine();
                        }

                        System.out.print("Grade: ");
                        int grade = Integer.parseInt(br.readLine());

                        school.registerStudent(sName, grade);
                        break;

                    case 2:
                        System.out.print("Teacher Name: ");
                        String tName = br.readLine();

                        while (tName.trim().isEmpty()) {
                            System.out.print("Name cannot be empty. Enter again: ");
                            tName = br.readLine();
                        }

                        System.out.print("Subject: ");
                        String subject = br.readLine();

                        school.registerTeacher(tName, subject);
                        break;

                    case 3:
                        System.out.print("Enter Name to Search: ");
                        String name = br.readLine();
                        school.searchByName(name);
                        break;

                    case 4:
                        school.displayAll();
                        break;

                    case 5:
                        System.out.println("Exiting program...");
                        return;

                    default:
                        System.out.println("Invalid choice!");
                }
            }

        } catch (Exception e) {
            System.out.println("Input error occurred!");
        }
    }
}

