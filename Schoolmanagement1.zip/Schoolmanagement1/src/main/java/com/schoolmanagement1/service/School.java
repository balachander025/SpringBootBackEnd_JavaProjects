package com.schoolmanagement1.service;

import com.schoolmanagement1.model.Student;
import com.schoolmanagement1.model.Teacher;
import java.util.*;

public class School {

    private List<Student> students = new ArrayList<>();
    private List<Teacher> teachers = new ArrayList<>();

    // Register student
    public void registerStudent(String name, int grade) {
        boolean exists = students.stream()
                .anyMatch(s -> s.getName().equalsIgnoreCase(name));

        if (exists) {
            System.out.println("Student already exists!");
        } else {
            students.add(new Student(name, grade));
            System.out.println("Student registered successfully.");
        }
    }

    // Register teacher
    public void registerTeacher(String name, String subject) {
        boolean exists = teachers.stream()
                .anyMatch(t -> t.getName().equalsIgnoreCase(name));

        if (exists) {
            System.out.println("Teacher already exists!");
        } else {
            teachers.add(new Teacher(name, subject));
            System.out.println("Teacher registered successfully.");
        }
    }

    // Search person by name (Java 8 Stream)
    public void searchByName(String name) {
        students.stream()
                .filter(s -> s.getName().equalsIgnoreCase(name))
                .forEach(s -> System.out.println(s.getDetails()));

        teachers.stream()
                .filter(t -> t.getName().equalsIgnoreCase(name))
                .forEach(t -> System.out.println(t.getDetails()));
    }

    // Display all
    public void displayAll() {
        students.forEach(s -> System.out.println(s.getDetails()));
        teachers.forEach(t -> System.out.println(t.getDetails()));
    }
}
