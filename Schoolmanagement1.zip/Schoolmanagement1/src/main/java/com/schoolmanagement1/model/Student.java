package com.schoolmanagement1.model;

public class Student extends Person {

    private int grade;

    public Student(String name, int grade) {
        super(name);
        this.grade = grade;
    }

    public int getGrade() {
        return grade;
    }

    @Override
    public String getDetails() {
        return String.format(
                "Student Name: %s, Grade: %d",
                getName(),
                grade
        );
    }
}

