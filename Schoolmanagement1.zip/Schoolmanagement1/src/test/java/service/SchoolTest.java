package service;

import com.schoolmanagement1.service.School;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.jupiter.api.Assertions.*;

class SchoolTest {

    private School school;
    private ByteArrayOutputStream outputStream;

    @BeforeEach
    void setUp() {
        school = new School();

        // Capture System.out
        outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));
    }

    // Test 1: Register student prints success message
    @Test
    void testRegisterStudent() {
        school.registerStudent("Ram", 8);

        String output = outputStream.toString();
        assertTrue(output.contains("Student registered successfully."));
    }

    // Test 2: Duplicate student prints duplicate message
    @Test
    void testDuplicateStudent() {
        school.registerStudent("Ram", 8);
        school.registerStudent("Ram", 9);

        String output = outputStream.toString();
        assertTrue(output.contains("Student already exists!"));
    }

    // Test 3: Register teacher prints success message
    @Test
    void testRegisterTeacher() {
        school.registerTeacher("Sita", "Math");

        String output = outputStream.toString();
        assertTrue(output.contains("Teacher registered successfully."));
    }

    // Test 4: Search by name prints correct student details
    @Test
    void testSearchStudentByName() {
        school.registerStudent("Anu", 6);
        outputStream.reset();

        school.searchByName("Anu");

        String output = outputStream.toString();
        assertTrue(output.contains("Student Name: Anu"));
    }

    // Test 5: Display all prints student and teacher
    @Test
    void testDisplayAll() {
        school.registerStudent("Asha", 5);
        school.registerTeacher("Manoj", "English");
        outputStream.reset();

        school.displayAll();

        String output = outputStream.toString();
        assertTrue(output.contains("Student Name: Asha"));
        assertTrue(output.contains("Teacher Name: Manoj"));
    }
}

