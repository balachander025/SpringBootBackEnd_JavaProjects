package com.LibraryManagement.model;

import java.time.LocalDate;

public class Book {
    private int id;
    private String title;
    private boolean borrowed;
    private int borrowCount;
    private LocalDate lastBorrowedDate;

    public Book(int id, String title) {
        this.id = id;
        this.title = title;
        this.borrowed = false;
        this.borrowCount = 0;
    }

    public int getId() { return id; }
    public String getTitle() { return title; }
    public boolean isBorrowed() { return borrowed; }
    public int getBorrowCount() { return borrowCount; }
    public LocalDate getLastBorrowedDate() { return lastBorrowedDate; }

    public void borrow() {
        borrowed = true;
        borrowCount++;
        lastBorrowedDate = LocalDate.now();
    }

    public void returnBook() {
        borrowed = false;
    }
}
