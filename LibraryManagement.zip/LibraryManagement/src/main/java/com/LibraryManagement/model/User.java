package com.LibraryManagement.model;

import java.util.ArrayList;
import java.util.List;

public class User {
    private int id;
    private String name;
    private List<Book> borrowedBooks = new ArrayList<>();
    private List<Book> history = new ArrayList<>();

    public User(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public List<Book> getBorrowedBooks() { return borrowedBooks; }
    public List<Book> getHistory() { return history; }

    public void borrowBook(Book book) {
        borrowedBooks.add(book);
        history.add(book);
    }

    public void returnBook(Book book) {
        borrowedBooks.remove(book);
    }
}
