package com.LibraryManagement.service;

import com.LibraryManagement.model.Book;
import com.LibraryManagement.model.User;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

public class LibraryService {

    private List<User> users = new ArrayList<>();
    private List<Book> books = new ArrayList<>();
    private Map<Book, LocalDate> borrowMap = new HashMap<>();

    public void addUser(User user) {
        users.add(user);
    }

    public void addBook(Book book) {
        books.add(book);
    }

    public List<Book> getBooks() {
        return books;
    }

    public User findUser(int id) {
        return users.stream().filter(u -> u.getId() == id).findFirst().orElse(null);
    }

    public Book findBook(int id) {
        return books.stream().filter(b -> b.getId() == id).findFirst().orElse(null);
    }

    public boolean lendBook(int userId, int bookId) {
        User user = findUser(userId);
        Book book = findBook(bookId);

        if (user == null || book == null || book.isBorrowed()) {
            return false;
        }

        book.borrow();
        user.borrowBook(book);
        borrowMap.put(book, LocalDate.now());
        return true;
    }

    public void returnBook(int userId, int bookId) {
        User user = findUser(userId);
        if (user == null) return;

        Book book = user.getBorrowedBooks()
                .stream()
                .filter(b -> b.getId() == bookId)
                .findFirst().orElse(null);

        if (book != null) {
            book.returnBook();
            user.returnBook(book);
            borrowMap.remove(book);
        }
    }

    // Reports
    public void showCurrentlyBorrowedBooks() {
        borrowMap.entrySet().stream()
                .sorted(Map.Entry.<Book, LocalDate>comparingByValue().reversed())
                .forEach(e -> System.out.println(e.getKey().getTitle() + " | " + e.getValue()));
    }

    public void groupUsersByBorrowCount() {
        users.stream()
                .collect(Collectors.groupingBy(u -> u.getBorrowedBooks().size()))
                .forEach((k, v) ->
                        System.out.println("Users with " + k + " books: " +
                                v.stream().map(User::getName).collect(Collectors.joining(", "))));
    }

    public void userHistory(int userId) {
        User user = findUser(userId);
        if (user == null) return;

        user.getHistory().stream()
                .map(Book::getTitle)
                .sorted()
                .forEach(System.out::println);
    }

    public void top3Books() {
        books.stream()
                .sorted(Comparator.comparingInt(Book::getBorrowCount).reversed())
                .limit(3)
                .forEach(b -> System.out.println(b.getTitle() + " - " + b.getBorrowCount()));
    }
}
