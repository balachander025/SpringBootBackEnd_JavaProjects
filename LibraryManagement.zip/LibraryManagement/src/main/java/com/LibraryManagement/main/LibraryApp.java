package com.LibraryManagement.main;

import com.LibraryManagement.model.Book;
import com.LibraryManagement.model.User;
import com.LibraryManagement.service.LibraryService;
import java.io.*;

public class LibraryApp {

    public static void main(String[] args) throws Exception {

        LibraryService service = new LibraryService();
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        // Register User
        System.out.print("Enter User Name: ");
        String name = br.readLine().trim();
        while (name.isEmpty()) {
            System.out.print("Name cannot be empty. Enter again: ");
            name = br.readLine().trim();
        }
        service.addUser(new User(1, name));

        // Register Books
        service.addBook(new Book(1, "Java Basics"));
        service.addBook(new Book(2, "Spring Boot"));
        service.addBook(new Book(3, "Data Structures"));
        service.addBook(new Book(4,"Spring Boot"));

        // Show Books
        System.out.println("\nAvailable Books:");
        service.getBooks().forEach(b ->
                System.out.println(b.getId() + ". " + b.getTitle()));

        // Borrow Book
        System.out.print("\nChoose Book ID to borrow: ");
        int bookId = Integer.parseInt(br.readLine());

        boolean success = service.lendBook(1, bookId);
        System.out.println(success ? "Book borrowed successfully" : "Book not available");

        // Reports
        System.out.println("\nCurrently Borrowed Books:");
        service.showCurrentlyBorrowedBooks();

        System.out.println("\nUser Grouping:");
        service.groupUsersByBorrowCount();

        System.out.println("\nUser Borrow History:");
        service.userHistory(1);

        System.out.println("\nTop 3 Books:");
        service.top3Books();
    }
}
