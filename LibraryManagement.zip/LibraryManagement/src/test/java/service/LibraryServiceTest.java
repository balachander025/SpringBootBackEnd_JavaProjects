package service;


import com.LibraryManagement.model.Book;
import com.LibraryManagement.model.User;
import com.LibraryManagement.service.LibraryService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class LibraryServiceTest {

    private LibraryService service;

    @BeforeEach
    void setUp() {
        service = new LibraryService();

        service.addUser(new User(1, "Alice"));
        service.addUser(new User(2, "Bob"));

        service.addBook(new Book(1, "Java Basics"));
        service.addBook(new Book(2, "Spring Boot"));
    }

    @Test
    void testAddUser() {
        User user = service.findUser(1);
        assertNotNull(user);
        assertEquals("Alice", user.getName());
    }

    @Test
    void testAddBook() {
        Book book = service.findBook(1);
        assertNotNull(book);
        assertEquals("Java Basics", book.getTitle());
    }

    @Test
    void testLendBookSuccessfully() {
        boolean result = service.lendBook(1, 1);
        assertTrue(result);
        assertTrue(service.findBook(1).isBorrowed());
    }

    @Test
    void testLendAlreadyBorrowedBookFails() {
        service.lendBook(1, 1);
        boolean result = service.lendBook(2, 1);
        assertFalse(result);
    }

    @Test
    void testReturnBook() {
        service.lendBook(1, 1);
        service.returnBook(1, 1);
        assertFalse(service.findBook(1).isBorrowed());
    }

    @Test
    void testUserBorrowHistory() {
        service.lendBook(1, 1);
        service.lendBook(1, 2);

        User user = service.findUser(1);
        assertEquals(2, user.getHistory().size());
    }
}

