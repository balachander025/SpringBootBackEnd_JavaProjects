package com.Schoolmanagement2.school_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchoolManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
