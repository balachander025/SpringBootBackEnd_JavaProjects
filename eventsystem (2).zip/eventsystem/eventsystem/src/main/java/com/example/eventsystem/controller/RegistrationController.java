package com.example.eventsystem.controller;

import com.example.eventsystem.entity.Registration;
import com.example.eventsystem.repository.RegistrationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/registrations")
public class RegistrationController {

    @Autowired
    private RegistrationRepository registrationRepository;

    @PostMapping
    public Registration register(@RequestBody Registration registration) {
        return registrationRepository.save(registration);
    }

    @GetMapping
    public List<Registration> getAll() {
        return registrationRepository.findAll();
    }
}
