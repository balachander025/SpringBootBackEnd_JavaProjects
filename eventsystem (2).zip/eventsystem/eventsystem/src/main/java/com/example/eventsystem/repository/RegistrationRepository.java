package com.example.eventsystem.repository;

import com.example.eventsystem.entity.Registration;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RegistrationRepository extends JpaRepository<Registration, Integer> {}
