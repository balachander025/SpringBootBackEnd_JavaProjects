package com.example.eventsystem.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class Registration {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private int eventId;
    private int attendeeId;
}
