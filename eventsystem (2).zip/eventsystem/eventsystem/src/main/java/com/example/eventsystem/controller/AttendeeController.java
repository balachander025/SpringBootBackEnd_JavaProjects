package com.example.eventsystem.controller;

import com.example.eventsystem.entity.Attendee;
import com.example.eventsystem.repository.AttendeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/attendees")
public class AttendeeController {

    @Autowired
    private AttendeeRepository attendeeRepository;

    @PostMapping
    public Attendee addAttendee(@RequestBody Attendee attendee) {
        return attendeeRepository.save(attendee);
    }

    @GetMapping
    public List<Attendee> getAll() {
        return attendeeRepository.findAll();
    }
}
