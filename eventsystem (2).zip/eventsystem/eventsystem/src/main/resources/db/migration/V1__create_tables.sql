CREATE TABLE event (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    date DATE
);

CREATE TABLE attendee (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100)
);

CREATE TABLE registration (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT,
    attendee_id INT,
    FOREIGN KEY (event_id) REFERENCES event(id),
    FOREIGN KEY (attendee_id) REFERENCES attendee(id)
);
