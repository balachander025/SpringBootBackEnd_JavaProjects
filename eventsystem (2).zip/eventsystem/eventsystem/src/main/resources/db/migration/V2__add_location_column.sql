ALTER TABLE event
ADD location VARCHAR(100);
